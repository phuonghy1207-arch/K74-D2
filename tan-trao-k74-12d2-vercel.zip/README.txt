HTML
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thông tin chuyển khoản</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f6f9;
            color: #333;
            text-align: center;
            padding: 20px;
            margin: 0;
        }
        .container {
            max-width: 400px;
            background: #fff;
            margin: 40px auto;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        h2 {
            color: #0066cc;
            margin-bottom: 10px;
        }
        p {
            font-size: 15px;
            color: #555;
        }
        .qr-code {
            width: 220px;
            height: auto;
            margin: 20px 0;
            border-radius: 8px;
            border: 1px solid #ddd;
        }
        .bank-info {
            background: #f9f9f9;
            padding: 12px;
            border-radius: 8px;
            font-size: 14px;
            text-align: left;
            margin-top: 15px;
        }
    </style>
</head>
<body>

    <div class="container" id="chuyen-khoan">
        <h2>Mừng Cưới / Chuyển Khoản</h2>
        <p>Cảm ơn sự hiện diện và tình cảm của bạn!</p>
        
        <!-- Thay link ảnh QR của bạn vào đây hoặc để file ảnh trong cùng thư mục -->
        <img src="link_anh_qr_cua_ban.png" alt="Mã QR Chuyển Khoản" class="qr-code">

        <div class="bank-info">
            <p><strong>Ngân hàng:</strong> vietcombank</p>
            <p><strong>Số tài khoản:</strong> 1234567890</p>
            <p><strong>Chủ tài khoản:</strong> NGUYEN VAN A</p>
            <p><strong>Nội dung:</strong> [Tên của bạn] mung cưới</p>
        </div>
    </div>

</body>
</html>